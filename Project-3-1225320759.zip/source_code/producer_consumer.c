#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/kthread.h>
#include <linux/semaphore.h>
#include <linux/delay.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Micaela Leong");

static int prod = 0;
static int cons = 0;
static int size = 0;

module_param(prod, int, 0);
module_param(cons, int, 0);
module_param(size, int, 0);

struct semaphore empty;
struct semaphore full;

static struct task_struct **producers;
static struct task_struct **consumers;

static int producer_thread(void *data) {
	int num = (int)(long)data;
	while (!kthread_should_stop()) {
		down_interruptible(&empty);
		printk("An item has been produced by Producer-%d\n", num);
		up(&full);
	}

	return 0;
}

static int consumer_thread(void *data) {
	int num = (int)(long)data;
	while (!kthread_should_stop()) {
		down_interruptible(&full);
		printk("An item has been consumed by Consumer-%d\n", num);
		up(&empty);
	}

	return 0;
}

static int __init producer_consumer_init(void) {
	int i;

	sema_init(&empty, size);
	sema_init(&full, 0);

	producers = kmalloc_array(prod, sizeof(struct task_struct *), GFP_KERNEL);
	for (int i = 0; i < prod; i++)  {
		producers[i] = kthread_run(producer_thread, &i, "Producer-%d", i);
	}

	consumers = kmalloc_array(cons, sizeof(struct task_struct *), GFP_KERNEL);
	for (int i = 0; i < cons; i++) {
		consumers[i] = kthread_run(consumer_thread, &i, "Consumer-%d", i);
	}

	return 0;
}

static void __exit producer_consumer_exit(void) {
	int i;

	for (int i = 0; i < prod; i++) {
		kthread_stop(producers[i]);
	}

	for (int i = 0; i < cons; i++) {
		kthread_stop(consumers[i]);
	}

	kfree(producers);
	kfree(consumers);

}

module_init(producer_consumer_init);
module_exit(producer_consumer_exit);

